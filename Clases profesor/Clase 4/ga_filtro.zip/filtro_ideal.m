function [costo] = filtro_ideal(filtro)

points = 5e3;
fc = 0.3;
length(filtro);
X = abs(fft(filtro,2*points));
Xideal = zeros(1,points);
Xideal(1:round(fc*2*points)) = 1;
costo = sum((X(1:points) - Xideal).^2)./points;