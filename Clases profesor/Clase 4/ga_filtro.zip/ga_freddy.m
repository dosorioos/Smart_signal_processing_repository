clear; close all; clc;

N = 8;
options = optimoptions("ga",PlotFcn="gaplotbestf");
[x,costo] = ga(@filtro_ideal,N,[],[],...
    [],[],[],[],[],options);

figure;
X = abs(fft(x,2e4));
plot((0:9999)./2e4,X(1:1e4));
xlabel('f');
title(sprintf('Espectro de Magnitud. MSE = %.6f',costo));
grid on;